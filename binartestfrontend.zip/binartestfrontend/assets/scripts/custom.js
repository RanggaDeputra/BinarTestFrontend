var count_add_detail = 2;
var base_url = window.location.origin + "/" + "BinarTestFrontEnd/";
var base_url_img = window.location.origin + "/" + "BinarTestFrontEnd/assets/img/dokumen/";

var user_type = false;

$("#pesan-error, #pesan-sukses, #pesan-error-detail, #pesan-error-la, #pesan-error-inner").hide();


function isValidEmail(email) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function saveMessage(){
    if(!$("#message").val()){
        $("#message").focus();
        return false;
    }
}

function saveUserAccess(){
    if(!$("#product_name").val()){
        $("#pesan-error").html('Product Name wajib diisi!').show();
        $("#product_name").focus();
        return false;
    }else if(!$("#product_price").val()){
        $("#pesan-error").html('Product Price wajib diisi!').show();
        $("#product_price").focus();
        return false;
    }else if(!$("#product_photo").val()){
        $("#pesan-error").html('Foto wajib diisi!').show();
        $("#product_photo").focus();
        return false;
    }
}

function detailUserAccess(id){

	var data = new FormData();
    data.append('Product_ID', id);
    var url = window.location.origin + "/garnis/garnis_back_office/useraccess/detail";

    $.ajax({
      url: url,
      type: 'POST',
      data: data, 
      processData: false,
      contentType: false,
      dataType: "json",
      beforeSend: function(e) {
        if(e && e.overrideMimeType) {
          e.overrideMimeType("application/json;charset=UTF-8");
        }
      },
      success: function(response){       
        if(response.status == "success"){ 
			$("#Product_ID").val(response.data.Product_ID);
			$("#product_name_detail").val(response.data.ProductName);
			$("#product_price_detail").val(response.data.Price);
            $("#product_photo_detail").attr("src", base_url_img + response.data.ImagePhoto);
        }
       },
      error: function (xhr, ajaxOptions, thrownError) { 
        alert(xhr.responseText);
      }
    });
}


function editUserAccess(){
    if(!$("#product_name_detail").val()){
        $("#pesan-error-detail").html('Nama Product wajib diisi!').show();
        $("#product_name_detail").focus();
        return false;
    }else if(!$("#product_price_detail").val()){
        $("#pesan-error-detail").html('Harga Product wajib diisi!').show();
        $("#product_price_detail").focus();
        return false;
    }
}

function deleteUserAccess(){
	$("#modal-detail").modal('hide');
	$("#id").val($("#Product_ID").val());
}