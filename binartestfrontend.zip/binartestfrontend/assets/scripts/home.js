$('.nav a[href~="' + location.href + '"]').addClass('active');

		$(".curency").mask("000.000.000.000.000.000", {reverse:true});

		
	   //Timepicker
	    $(".time-picker").timepicker({
	      showInputs: false,
	      showMeridian: false,
	    });

	    $('#table_user_access').DataTable({
	      	responsive: true,
	      	order: []
	    });
        
        $('#modal-add, #modal-detail').on('shown.bs.modal', function () {
            $('#us3, #us3_detail').locationpicker('autosize');
        });

        $("#pesan-error-password").hide();