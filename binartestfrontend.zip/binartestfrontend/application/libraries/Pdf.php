<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * CodeIgniter DomPDF Library
 *
 * Generate PDF's from HTML in CodeIgniter
 *
 * @package			CodeIgniter
 * @subpackage		Libraries
 * @category		Libraries
 * @author			Ardianta Pargo
 * @license			MIT License
 * @link			https://github.com/ardianta/codeigniter-dompdf
 */
use Dompdf\Dompdf;
class Pdf extends Dompdf{
	/**
	 * PDF filename
	 * @var String
	 */
	public $filename;
	public function __construct(){
		parent::__construct();
		$this->filename = "laporan.pdf";
	}
	/**
	 * Get an instance of CodeIgniter
	 *
	 * @access	protected
	 * @return	void
	 */
	protected function ci()
	{
		return get_instance();
	}
	/**
	 * Load a CodeIgniter view into domPDF
	 *
	 * @access	public
	 * @param	string	$view The view to load
	 * @param	array	$data The view data
	 * @return	void
	 */
	public function load_view($view, $data = array()){
		$html = $this->ci()->load->view($view, $data, TRUE);
		$this->load_html($html);
		// Render the PDF
		$this->render();
        // Output the generated PDF to Browser
        $this->stream($this->filename, array("Attachment" => false));
	}

	public function download_pdf($html){
		$this->load_html($html);
		// Render the PDF
		$this->render();
        // Output the generated PDF to Browser
        $output = $this->output();

        file_put_contents('assets/invoice/' . $this->filename, $output);
	}

	function createPDF($html, $filename=''){
       	
       	$customPaper = array(0,0,800,1500);
		$this->set_paper(/*$customPaper, */'landscape');
        $this->load_html($html);
        $this->render();
        //$this->stream($filename, array('Attachment' => 0));
        $output = $this->output();
        $write_output = file_put_contents('assets/invoice/' . $filename, $output);

        return $write_output;
    }
}