<!doctype html>
<html lang="en">

<head>
	<title>Binar Test Frontend</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/linearicons/style.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/chartist/css/chartist-custom.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/demo.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/custom.css" media="screen">

	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables/media/css/jquery.dataTables.min.css">	
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables/media/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datatables/extensions/Buttons/css/buttons.dataTables.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/select2/select2.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/iCheck/all.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/datepicker/datepicker3.css">
	<link rel='stylesheet' href='<?php echo base_url(); ?>assets/vendor/full-calendar/css/fullcalendar.min.css'>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendor/timepicker/bootstrap-timepicker.min.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<!-- <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url(); ?>assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="<?php echo base_url(); ?>assets/img/favicon.png"> -->
</head>

<body>
	<!-- Javascript -->
	<script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/moment/moment.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src='<?php echo base_url(); ?>assets/vendor/full-calendar/js/fullcalendar.min.js'></script>
	<script src="<?php echo base_url(); ?>assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/scripts/klorofil-common.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/datatables/media/js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/datatables/extensions/Buttons/js/dataTables.buttons.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/datatables/extensions/Buttons/js/buttons.flash.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/datatables/extensions/Buttons/js/buttons.html5.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/select2/select2.full.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/iCheck/icheck.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/datepicker/bootstrap-datepicker.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/timepicker/bootstrap-timepicker.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/vendor/zoom-image/jquery.zoom.min.js"></script>
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB49n_oRjDn2uIes7Cfo71ZJBbAQElJ4vY&libraries=places"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/location-picker/locationpicker.jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/mask/jquery.mask.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/jsPDF/jspdf.min.js"></script>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<?php echo $this->load->view('nav_view', $view, true); ?>
		</nav>
		<!-- END NAVBAR -->
		<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<?php echo $this->load->view('side_view', $view, true); ?>
		</div>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
		<div id="loader"></div>
		<div class="main">
			<br>
			 <?php
		          $msg_danger = $this->session->flashdata('msg_danger');
		          $msg_success = $this->session->flashdata('msg_success');

		          if (!empty($msg_success)) {
		      ?>
				<div class="col-md-12">
					<div class="alert alert-success alert-dismissible col-md-4 pull-right" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<i class="fa fa-check-circle"></i> <?php echo $msg_success; ?>
					</div>
				</div>
			<?php } elseif (!empty($msg_danger)) {
			?>
			<div class="col-md-12">
				<div class="alert alert-danger alert-dismissible col-md-4 pull-right" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<i class="fa fa-times-circle"></i> <?php echo $msg_danger; ?>
				</div>
			</div>
			<?php } ?>
			<?php echo $this->load->view($content, $view, true); ?>
		</div>

		</div>
		    </div>
		<!-- END MAIN -->
		<div class="clearfix"></div>
		<footer>

		</footer>
	</div>
	<script src="<?php echo base_url(); ?>assets/scripts/home.js"></script>
    <script src="<?php echo base_url(); ?>assets/scripts/custom.js"></script>
    <script type="text/javascript">
	  $(window).load(function() { $("#loader").fadeOut("slow"); })
	</script>
</body>

</html>
