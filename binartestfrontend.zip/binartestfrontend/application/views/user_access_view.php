<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<a href="#" data-toggle="modal" data-target="#modal-add" class="btn btn-primary btn-lg pull-right"><span class="glyphicon glyphicon-plus"></span>Product List</a>
							<div class="panel-header">
								<span class="page-title">Product List</span>
							</div>
							<div class="panel">
								<div class="panel-body">
									<?php
									    foreach($data->result() as $row){
									?>
										<div class="col-md-4">
											<div class="panel">
												<div class="panel-body">
													<div class="col-md-4">
														<img src="<?php echo base_url('assets/img/dokumen/').$row->ImagePhoto; ?>" class="img-circle" alt="Avatar" width="100" height="100">
													</div>
													<div class="col-md-8">
														<div><b><?php echo $row->ProductName ?></b></div>
														<div>ID : <?php echo $row->ProductNo ?></div>
														<div>Price : <?php echo $row->Price ?></div><br>
														<div class="text-right"><a href="#" data-toggle="modal" data-target="#modal-detail" onclick="detailUserAccess(<?php echo $row->Product_ID; ?>);">Detail</a></div>
														
													</div>
												</div>
											</div>
										</div>
									<?php
									    }
									?>
								</div>
							</div>
						</div>
												
					</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->

			<div id="modal-add" class="modal fade">
			    <div class="modal-dialog">
				    <div class="modal-content">
				    	<form class="form-horizontal" autocomplete="off" role="form" method="POST" enctype="multipart/form-data" action="<?php echo base_url('useraccess/save'); ?>" onsubmit="return saveUserAccess();"> 
				        <div class="modal-header">
				          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				          <h3 class="modal-title">
				            Tambah Product
				          </h3>
				        </div>
				        <div class="modal-body">
				        	<div class="col-md-12">
								<div id="pesan-error" class="alert alert-danger text-center"></div>
							</div>
							<div class="form-group required">
								<label class="col-md-3 control-label">Nama Product</label>
								<div class="col-md-9">
									<input class="form-control" type="text" id="product_name" name="product_name">
								</div>
							</div>
							<div class="form-group required">
								<label class="col-md-3 control-label">Harga</label>
								<div class="col-md-9">
									<input class="form-control" type="text" id="product_price" name="product_price">
								</div>
							</div>	
							<div class="form-group required">
								<label class="col-md-3 control-label">Foto</label>
								<div class="col-md-9">
									<input class="form-control" type="file" accept="image/jpeg, image/png" id="product_photo" name="product_photo">
								</div>
							</div>			
						</div>
				        <div class="modal-footer">
							<button type="submit" class="btn btn-primary btn-lg pull-right"><span class="glyphicon glyphicon-ok"></span> Simpan</button>
						</div>
						</form>
				    </div>
			    </div>
			</div>

			<div id="modal-detail" class="modal fade">
			    <div class="modal-dialog">
				    <div class="modal-content">
				    	<form class="form-horizontal" autocomplete="off" role="form" method="POST" enctype="multipart/form-data" action="<?php echo base_url('useraccess/update'); ?>" onsubmit="return editUserAccess();"> 
				        <div class="modal-header">
				          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				          <h3 class="modal-title">
				            Detail Product
				          </h3>
				        </div>
						<div class="modal-body">
				        	<div class="col-md-12">
								<div id="pesan-error-detail" class="alert alert-danger text-center"></div>
								<input class="form-control" type="hidden" id="Product_ID" name="Product_ID">
							</div>
							<div class="form-group text-center">
								<img id="product_photo_detail" src="#" class="img-circle" alt="Avatar" width="100" height="100">
							</div>
							<div class="form-group required">
								<label class="col-md-3 control-label">Product Name</label>
								<div class="col-md-9">
									<input class="form-control" type="text" id="product_name_detail" name="product_name_detail">
								</div>
							</div>
							<div class="form-group required">
								<label class="col-md-3 control-label">Price</label>
								<div class="col-md-9">
									<input class="form-control" type="text" id="product_price_detail" name="product_price_detail">
								</div>
							</div>
							<div class="form-group">
								<label class="col-md-3 control-label">Foto</label>
								<div class="col-md-9">
									<input class="form-control" type="file" accept="image/jpeg, image/png" id="PhotoImage" name="PhotoImage">
								</div>
							</div>			
						</div>
				        <div class="modal-footer">
							<button type="button" class="btn btn-danger btn-lg" onclick="deleteUserAccess();" data-toggle="modal" data-target="#modal-delete"><span class="glyphicon glyphicon-remove"></span> Hapus</button>
							<button type="submit" class="btn btn-primary btn-lg"><span class="glyphicon glyphicon-ok"></span> Ubah</button>
						</div>
						</form>
				    </div>
			    </div>
			</div>

			<div id="modal-delete" class="modal fade">
		    <div class="modal-dialog">
		      <div class="modal-content">
		        <form id="form" method="POST" action="<?php echo base_url('useraccess/delete');?>">
		        <div class="modal-header">
		          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		          <h3 class="modal-title">
		            Konfirmasi
		          </h3>
		        </div>
		        <div class="modal-body">
		          <input type="hidden" id="id" name="id">
		          Anda yakin ingin menghapus data ini?
		        </div>
		        <div class="modal-footer">
		        	<button type="button" class="btn btn-default btn-lg" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>Batal</button>
		          <button type="submit" class="btn btn-danger btn-lg"><span class="glyphicon glyphicon-ok"></span> Ya, Hapus</button>
		        </div>
		        </form>
		      </div>
		    </div>
		  </div>
