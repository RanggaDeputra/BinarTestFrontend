<div class="container-fluid">
	<div id="navbar-menu">
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
				<a href="<?php echo base_url('home/logout'); ?>"><i class="lnr lnr-exit"></i> <span>Logout</span></a>
			</li>
		</ul>
	</div>
</div>

			