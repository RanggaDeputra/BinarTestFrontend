<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="panel-header">
								<span class="page-title">Log</span>
							</div>
							<div class="panel">
								<div class="panel-body">
									<table id="table_user_access" class="display" style="width:100%">
									    <thead>
									        <tr>
									            <th class="text-center">Tanggal</th>
									            <th class="text-center">Jam</th>
									            <th>Message</th>
									        </tr>
									    </thead>
									    <tbody>
									    	<?php
									    		foreach($data->result() as $row){
									    	?>
									    	<tr>
									            <td class="text-center"><?php echo date("d-M-Y", strtotime($row->logcat_date));?></td>
									            <td class="text-center"><?php echo date("H:i:s", strtotime($row->logcat_date));?></td>
									            <td><?php echo $row->logcat_message?></td>
									        </tr>
									    	<?php
									    		}
									    	?>
									    </tbody>
									</table>
								</div>
							</div>
						</div>		
					</div>
				</div>
			</div>