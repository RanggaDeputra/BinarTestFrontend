<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
	

	function cryptox( $string, $action = 'e' ) {
	    // you may change these values to your own
	    $secret_key = '#AdineSRI';
	    $secret_iv = '#AdineSRI';
	 
	    $output = false;
	    $encrypt_method = "AES-256-CBC";
	    $key = hash( 'sha256', $secret_key );
	    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );
	 
	    if( $action == 'e' ) {
	        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
	    }
	    else if( $action == 'd' ){
	        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
	    }
	 
	    return $output;
	}
	
	function random_num($size) {
	  $key = '';
	  $keys = range(0, 9);

	  for ($i = 0; $i < $size; $i++) {
	    $key .= $keys[array_rand($keys)];
	  }

	  return $key;
  	}

  	function random_string($length = 8) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWQYZ';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}

	function compareDate($date){

		$today = (new DateTime())->format('Y-m-d');
		$expiry = (new DateTime($date))->format('Y-m-d');

		if ($today > $expiry) {
			$result = "true";
		}else{
			$result = "false";
		}

		return $result;
	}

	function diff_date($dt1, $dt2){
		$date1 = date_create($dt1);
		$date2 = date_create($dt2);
		$diff = date_diff($date1,$date2);
		return $diff->format("%R%a");
	}


	function unsetKey($array, $key_unset){
		$new_array = array();
		for ($i=0; $i < count($array); $i++) { 
			$obj = get_object_vars($array[$i]);
			unset($obj[$key_unset]);
			array_push($new_array, $obj);
		}
		return $new_array;
	}

	function ageCalculator($dob){
	    if(!empty($dob)){
	        $birthdate = new DateTime($dob);
	        $today   = new DateTime('today');
	        $age = $birthdate->diff($today)->y;
	        return $age;
	    }else{
	        return 0;
	    }
	}

?>