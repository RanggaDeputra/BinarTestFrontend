<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function index()
	{	
		$username = $this->session->userdata('username');
		if (!empty($username)) {
			redirect('login');
		}else{
			$this->load->view('login_view');
		}

	}

	public function sign_in(){
		$username = $this->input->post('username');
        $password	= $this->input->post('password');
        $encrypt_password = md5($password);

		 
        $sql = "SELECT * FROM usermaster LEFT JOIN product ON product.userid = usermaster.id WHERE username = '$username' AND password = '$encrypt_password'";
		$status	= $this->db->query($sql);
		//vdebug($sql);
        if ($status->num_rows() > 0) {
			
			foreach ($status->result() as $row) {
				# code...
				$array = array(
					'id' => $row->Product_ID,
					'userid' => $row->ID,
					'no' => $row->ProductNo,
					'username' => $row->Username,
					'name' => $row->ProductName,
					'prices' => $row->Price,
					'foto' => $row->ImagePhoto
				);//vdebug($array);
				$this->session->set_userdata($array);
				redirect('useraccess');
			}
		}else{
   			$this->session->set_flashdata('messages', 'Email or password incorect');
			redirect('login');
		}
	}
}
