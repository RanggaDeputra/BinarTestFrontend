<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Log extends CI_Controller {
	
	public function index()
	{	
		$this->MSessionLogin->session_login();
		$content['view']		= '';
		$content['content']		= 'log_view';
		$content['title']		= 'Log';

		$this->db->order_by('logcat_date', 'DESC');
		$content['data'] 		= $this->db->get('logcat');

		$this->load->view('home_view', $content);
	}
}