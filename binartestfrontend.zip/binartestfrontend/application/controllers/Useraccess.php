<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Useraccess extends CI_Controller {
	
	public function index()
	{	
		$this->MSessionLogin->session_login();
		$content['view']		= '';
		$content['content']		= 'user_access_view';
		$content['title']		= 'User Access';
		

		$this->db->where('p.rowstatus', '0');
		$this->db->where('p.userid', $this->session->userdata('userid'));
		$this->db->join('product p', 'p.userid = u.id', 'left');
		$content['data'] = $this->db->get('usermaster u');

		$this->load->view('home_view', $content);
	}

	public function create(){
		$this->MSessionLogin->session_login();
		$content['view']		= '';
		$content['content']		= 'add_user_access_view';
		$content['title']		= 'Create';
		$this->load->view('home_view', $content);
	}

	public function save(){

		$this->MSessionLogin->session_login();
		
		$product_name = $this->input->post('product_name');
		$product_price = $this->input->post('product_price');
		$user_product_id = $this->session->userdata('userid');
	    $product_created_by = $this->session->userdata('username');
		$product_no = date("dmy");
		
		$this->db->select('productno');
		$this->db->where('substr(productno,5,6)', $product_no);
		$order_no = $this->db->get('product');
		
		
		if($order_no->num_rows() > 0)
		{
			for($i = 0; $i < $order_no->num_rows(); $i++) {
				$i++;			
			}
			$orderno = 'PROD' . $product_no .$i;
		}
		else
		{
			$orderno = 'PROD' . $product_no .$i;
		}
		//vdebug($order_no->num_rows());
        $config['upload_path']          = './assets/img/dokumen/';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 10000;
        $this->load->library('upload', $config);
		
		if (!$this->upload->do_upload('product_photo')) {
            echo $this->upload->display_errors();
        }else{
        	$upload_data = $this->upload->data(); 
			$file_name = $upload_data['file_name'];

			$query = $this->db->insert('product', array(
				'ProductName' => $product_name,
				'ProductNo' => $orderno,
	        	'Price' => $product_price,
	        	'UserID' => $user_product_id,
	        	'ImagePhoto' => $file_name,
	        	'CreatedBy' => $product_created_by,
				'CreatedTime' => date('Y-m-d H:i:s')
	        	));

			if ($query) {

				$this->session->set_flashdata('msg_success', 'product created is successfully');
				redirect('useraccess');

			}else{
				$this->session->set_flashdata('msg_danger', 'product created is failed');
				redirect('useraccess');
			}
		}
	}

	public function detail(){
		$this->MSessionLogin->session_login();
	    $product_id = $this->input->post('Product_ID');
	    $this->db->where('Product_Id', $product_id);
	    $result = $this->db->get('product')->row();
	    $response = array(
	    	'status'=>'success',
        	'data'=>$result
        );

        echo json_encode($response);
	}

	public function update(){

		$this->MSessionLogin->session_login();
		
		$product_id = $this->input->post('Product_ID');
		$product_name = $this->input->post('product_name_detail');
		$product_price = $this->input->post('product_price_detail');
		
	    $config['upload_path']          = './assets/img/dokumen/';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 10000;
        $this->load->library('upload', $config);

        if (strlen($_FILES['PhotoImage']['tmp_name']) <= 0) {
        	$this->db->where('Product_ID', $product_id);
		    $query = $this->db->update('product', array(
		    	'ProductName' => $product_name,
	        	'Price' => $product_price,
	        	'LastModifiedTime' => date('Y-m-d H:i:s'),
	        	'LastModifiedBy' => $this->session->userdata('username')
	        	));

			if ($query) {

				$this->session->set_flashdata('msg_success', 'Product updated is successfully');
				redirect('useraccess');

			}else{
				$this->session->set_flashdata('msg_danger', 'Product updated is failed');
				redirect('useraccess');
			}
        } else {
		
			if (!$this->upload->do_upload('PhotoImage')) {
	            echo $this->upload->display_errors();
	        }else{
	        	$upload_data = $this->upload->data(); 
				$file_name = $upload_data['file_name'];

				$this->db->where('Product_ID', $product_id);
			    $query = $this->db->update('product', array(
					'ProductName' => $product_name,
					'Price' => $product_price,
		        	'ImagePhoto' => $file_name,
					'LastModifiedTime' => date('Y-m-d H:i:s'),
					'LastModifiedBy' => $this->session->userdata('username')
		        	));

				if ($query) {

					$this->session->set_flashdata('msg_success', 'Product updated is successfully');
					redirect('useraccess');

				}else{
					$this->session->set_flashdata('msg_danger', 'Product updated is failed');
					redirect('useraccess');
				}
			}
		}

	   
	}

	public function delete(){

		$this->MSessionLogin->session_login();

		$product_id = $this->input->post('id');

	    $this->db->where('product_id', $product_id);
	    $query = $this->db->update('product', array(
        	'rowstatus' => '1'
        	));

		if ($query) {

			$this->session->set_flashdata('msg_success', 'Product deleted is successfully');
			redirect('useraccess');

		}else{
			$this->session->set_flashdata('msg_danger', 'Product deleted is failed');
			redirect('useraccess');
		}
	}
}
