<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	
	public function index()
	{	
		$username = $this->session->userdata('username');
		if (!empty($username)) {
			redirect('register');
		}else{
			$this->load->view('register_view');
		}

	}

	public function sign_up(){
		$username = $this->input->post('username');
		$email = $this->input->post('email');
        $password	= $this->input->post('password');
        $encrypt_password = md5($password);
		
		$user_no = date("dmy");
		
		$this->db->select('UserNo');
		$this->db->where('substr(UserNo,4,6)', $user_no);
		$userno = $this->db->get('usermaster');
		
		if($userno->num_rows() > 0)
		{
			for($i = 0; $i < $userno->num_rows(); $i++) {
				$i++;			
			}
			$usernodetail = 'MHK' . $user_no .$i;
		}
		else
		{
			$usernodetail = 'MHK' . $user_no .$i;
		}
		$query = $this->db->insert('usermaster', array(
			'Username' => $username,
			'UserNo' => $usernodetail,
			'Password' => $encrypt_password,
			'Email' => $email,
			'CreatedTime' => date('Y-m-d H:i:s'),
			'CreatedBy' => $username
		));
		 
		if ($query) {
			$this->session->set_flashdata('msg_success', 'product created is successfully, please re login with your account');
			redirect('login');
		}else{
			$this->session->set_flashdata('msg_danger', 'product created is failed');
			redirect('login');
		}
	}
}
